<?php

namespace App\Imports;

use App\Models\Etudiant;
use App\Models\Classes;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\SkipsOnError;
use Maatwebsite\Excel\Concerns\SkipsErrors;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Illuminate\Support\Facades\Log;

class EtudiantImport implements ToModel, WithHeadingRow, SkipsOnError, SkipsEmptyRows
{
    use SkipsErrors;

    protected int $classeId;
    protected int $campusId;
    protected int $importCount = 0;
    protected int $skipCount = 0;

    public function __construct(int $classeId, int $campusId)
    {
        $this->classeId = $classeId;
        $this->campusId = $campusId;
    }

    public function model(array $row): ?Etudiant
    {
        // Debug: log la ligne reçue
        Log::info('Import row: ' . json_encode($row));
        
        // Chercher le matricule
        $matricule = $this->findMatricule($row);
        
        Log::info('Matricule trouvé: ' . ($matricule ?? 'NULL'));

        if (!$matricule) {
            $this->skipCount++;
            return null;
        }

        // Vérifier si l'étudiant existe déjà
        $existingEtudiant = Etudiant::where('matricule', $matricule)->first();

        if ($existingEtudiant) {
            $existingEtudiant->update([
                'id_classe' => $this->classeId,
                'campus_id' => $this->campusId,
                'statut' => Etudiant::STATUT_INACTIF,
            ]);
            $this->skipCount++;
            Log::info('Étudiant existant mis à jour: ' . $matricule);
            return null;
        }

        $this->importCount++;
        Log::info('Nouvel étudiant créé: ' . $matricule);

        return new Etudiant([
            'matricule' => $matricule,
            'statut' => Etudiant::STATUT_INACTIF,
            'id_classe' => $this->classeId,
            'campus_id' => $this->campusId,
        ]);
    }

    protected function findMatricule(array $row): ?string
    {
        // Prendre la PREMIÈRE valeur non vide de la ligne
        foreach ($row as $key => $value) {
            if (!empty($value)) {
                $cleaned = trim((string) $value);
                if (!empty($cleaned)) {
                    Log::info("Colonne '$key' => '$cleaned'");
                    return $cleaned;
                }
            }
        }

        return null;
    }

    public function getImportCount(): int
    {
        return $this->importCount;
    }

    public function getSkipCount(): int
    {
        return $this->skipCount;
    }
}
