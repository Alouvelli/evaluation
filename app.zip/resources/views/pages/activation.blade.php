@php use App\Http\Controllers\CoursController; @endphp
@extends('layouts.admin')

@section('title', 'Activation des Évaluations')

@section('content')
    <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));">
        <!-- Current Evaluation Status -->
        <div class="stat-card"
             style="background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white;">
            <div class="stat-icon" style="background: rgba(255,255,255,0.2);">
                <i class="fas fa-calendar-check"></i>
            </div>
            <div class="stat-content">
                <p style="color: rgba(255,255,255,0.8); margin-bottom: 0.5rem;">Évaluation en cours</p>
                <h3 style="color: white; font-size: 1.25rem;">{{ CoursController::getEvaluationActive() }}</h3>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-toggle-on"></i> Changer l'évaluation active</h3>
        </div>
        <div class="card-body">
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong>Attention :</strong> Le changement de l'évaluation en cours implique sa clôture.
                    Les étudiants évalueront désormais sur l'année et le semestre définis.
                    Les statuts des étudiants seront réinitialisés.
                </div>
            </div>

            <form method="POST" action="{{ route('change_evaluation_active') }}" style="max-width: 600px;">
                @csrf

                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-calendar"></i> Année académique <span style="color: var(--danger);">*</span>
                    </label>
                    <select class="form-control form-select" name="annee" required>
                        <option value="">-- Sélectionner l'année académique --</option>
                        @foreach($an as $a)
                            <option value="{{ $a->id }}">{{ $a->annee1 }} - {{ $a->annee2 }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">
                        <i class="fas fa-clock"></i> Semestre <span style="color: var(--danger);">*</span>
                    </label>
                    <div style="display: flex; gap: 2rem; margin-top: 0.5rem;">
                        <label class="radio-card">
                            <input type="radio" name="semestre" value="1" required>
                            <div class="radio-card-content">
                                <i class="fas fa-1"></i>
                                <span>Semestre 1</span>
                            </div>
                        </label>
                        <label class="radio-card">
                            <input type="radio" name="semestre" value="2">
                            <div class="radio-card-content">
                                <i class="fas fa-2"></i>
                                <span>Semestre 2</span>
                            </div>
                        </label>
                    </div>
                </div>

                <div style="margin-top: 2rem;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-check"></i> Valider le changement
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-bolt"></i> Actions rapides</h3>
        </div>
        <div class="card-body">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem;">
                <a href="{{ route('etudiants.import') }}" class="action-card">
                    <div class="action-icon" style="background: var(--success);">
                        <i class="fas fa-file-import"></i>
                    </div>
                    <div class="action-content">
                        <h4>Importer Étudiants</h4>
                        <p>Importer la liste des étudiants par classe</p>
                    </div>
                </a>

                <a href="{{ route('tools') }}" class="action-card">
                    <div class="action-icon" style="background: var(--info);">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="action-content">
                        <h4>Gérer les Cours</h4>
                        <p>Ajouter ou modifier les cours</p>
                    </div>
                </a>

                <a href="{{ route('liste_prof') }}" class="action-card">
                    <div class="action-icon" style="background: var(--warning);">
                        <i class="fas fa-file-pdf"></i>
                    </div>
                    <div class="action-content">
                        <h4>Rapports</h4>
                        <p>Générer les rapports enseignants</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .radio-card {
            cursor: pointer;
            display: block;
        }

        .radio-card input {
            display: none;
        }

        .radio-card-content {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            padding: 1.5rem 2rem;
            border: 2px solid var(--gray-light);
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .radio-card-content i {
            font-size: 1.5rem;
            color: var(--gray);
        }

        .radio-card-content span {
            font-weight: 500;
            color: var(--gray);
        }

        .radio-card input:checked + .radio-card-content {
            border-color: var(--primary);
            background: rgba(102, 126, 234, 0.1);
        }

        .radio-card input:checked + .radio-card-content i,
        .radio-card input:checked + .radio-card-content span {
            color: var(--primary);
        }

        .radio-card:hover .radio-card-content {
            border-color: var(--primary-light);
        }

        .action-card {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.25rem;
            background: var(--light);
            border-radius: 12px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .action-card:hover {
            border-color: var(--primary);
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .action-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
        }

        .action-content h4 {
            font-size: 1rem;
            font-weight: 600;
            color: var(--dark);
            margin: 0 0 0.25rem 0;
        }

        .action-content p {
            font-size: 0.85rem;
            color: var(--gray);
            margin: 0;
        }
    </style>
@endpush
