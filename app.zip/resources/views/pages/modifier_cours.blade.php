@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                @endif
                <div class="card">
                    <div class="card-header text-white" style="background-color: #041f4e">Modification cours</div>

                    <div class="card-body">
                        <form method="POST" action="{{route('update_cours')}}">
                            @csrf

                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">Nom</label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control" name="libelle_cours" value="{{$cours->libelle_cours}}" required  style="border:2px solid #041f4e">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">Classe</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="id_classe" id="id_classe" required style="border:2px solid #041f4e">
                                        <option value="{{$cours->id_classe}}">{{$cours->libelle}} - {{$cours->libelle_niveau}}</option>
                                        @foreach(\App\Http\Controllers\ClassesController::getListClasse() as $c)
                                            @if($c->id != $cours->id)
                                            <option value="{{$c->id}}">{{$c->libelle}} - {{$c->libelle_niveau}}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">Professeur</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="id_professeur" id="id_professeur" required style="border:2px solid #041f4e">
                                        <option value="{{$cours->id_professeur}}">{{$cours->full_name}}</option>
                                        @foreach(\App\Http\Controllers\ProfesseursController::getListProfs() as $c)
                                            @if($c->id != $cours->id_professeur)
                                                <option value="{{$c->id}}">{{$c->full_name}}</option>
                                            @endif
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <input hidden name="id_cours" type="number" value="{{$cours->id_cours}}">
                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn text-white" style="background-color: #041f4e">Modifier</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
