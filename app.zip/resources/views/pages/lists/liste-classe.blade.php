@extends('layouts.admin')

@section('title', 'Liste des Classes')

@section('content')
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> Liste des Classes</h3>
            <span class="badge" style="background: rgba(255,255,255,0.2); color: white;">
                {{ $classes[0]->annee1 ?? '' }} - {{ $classes[0]->annee2 ?? '' }} | Semestre {{ $classes[0]->semestre ?? '' }}
            </span>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Classe</th>
                            <th>Niveau</th>
                            <th>Taux Participation</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($classes as $item)
                            @php
                                $tauxParticipation = \App\Http\Controllers\EvaluationsController::getTauxDeParticipation($item->id);
                            @endphp
                            <tr>
                                <td>{{ $item->id }}</td>
                                <td>
                                    <strong>{{ $item->libelle }}</strong>
                                </td>
                                <td>
                                    <span class="badge badge-primary">
                                        {{ \App\Http\Controllers\ClassesController::getNiveauDeLaClasse($item->id_niveau) }}
                                    </span>
                                </td>
                                <td>
                                    <div class="progress-bar-mini" style="width: 120px;">
                                        <div class="progress-fill-mini" style="width: {{ $tauxParticipation }}%; background: {{ $tauxParticipation < 50 ? 'var(--danger)' : ($tauxParticipation < 75 ? 'var(--warning)' : 'var(--success)') }};"></div>
                                    </div>
                                    <span style="font-weight: 600;">{{ $tauxParticipation }}%</span>
                                </td>
                                <td>
                                    <a href="{{ route('resultat', [
                                        'classe' => $item->libelle,
                                        'annee_id' => $item->annee_id,
                                        'semestre' => $item->semestre,
                                        'id_niveau' => $item->id_niveau,
                                        'campus_id' => $item->campus_id
                                    ]) }}" class="btn btn-primary btn-sm">
                                        <i class="fas fa-chart-bar"></i> Dépouillement
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@push('styles')
<style>
    .progress-bar-mini {
        height: 8px;
        background: var(--gray-light);
        border-radius: 4px;
        overflow: hidden;
        margin-bottom: 0.25rem;
    }

    .progress-fill-mini {
        height: 100%;
        border-radius: 4px;
        transition: width 0.5s ease;
    }
</style>
@endpush
