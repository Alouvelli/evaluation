@extends('layouts.admin')

@section('title', 'Liste des Enseignants')

@section('content')
    @php
        use App\Http\Controllers\EvaluationsController;
    @endphp

    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-chalkboard-teacher"></i> Liste des Enseignants</h3>
            <span class="badge-count">{{ $profs->count() }} enseignants</span>
        </div>
        <div class="card-body">
            @if($profs->count() > 0)
                <!-- Vue Desktop -->
                <div class="table-scroll-wrapper">
                    <table class="table-results">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="col-fixed">Nom complet</th>
                            <th class="col-note">Note Finale</th>
                            <th class="col-note">Appréciation</th>
                            <th class="col-note">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($profs as $index => $prof)
                            @php
                                $noteFinale = EvaluationsController::getNoteFinale($prof->id);

                                if ($noteFinale < 65) {
                                    $appreciation = 'Peu satisfaisant';
                                    $badgeClass = 'badge-danger';
                                } elseif ($noteFinale <= 85) {
                                    $appreciation = 'Satisfaisant';
                                    $badgeClass = 'badge-warning';
                                } else {
                                    $appreciation = 'Très satisfaisant';
                                    $badgeClass = 'badge-success';
                                }

                                $noteClass = $noteFinale >= 75 ? 'moy-success' : ($noteFinale >= 50 ? 'moy-warning' : 'moy-danger');
                            @endphp
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td class="col-fixed">
                                    <div class="prof-info">
                                        <div class="prof-avatar">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <strong>{{ $prof->full_name }}</strong>
                                    </div>
                                </td>
                                <td class="col-note">
                                    <span class="moyenne-badge {{ $noteClass }}">{{ $noteFinale }}/100</span>
                                </td>
                                <td class="col-note">
                                    <span class="appreciation-badge {{ $badgeClass }}">{{ $appreciation }}</span>
                                </td>
                                <td class="col-note">
                                    <div class="action-buttons">
                                        <a href="{{ route('resultat_prof', $prof->id) }}" class="btn-action btn-view" title="Voir détails">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('rapport_prof', $prof->id) }}" class="btn-action btn-pdf" title="Télécharger rapport">
                                            <i class="fas fa-file-pdf"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Vue Mobile Cards -->
                <div class="mobile-cards">
                    @foreach($profs as $prof)
                        @php
                            $noteFinale = EvaluationsController::getNoteFinale($prof->id);

                            if ($noteFinale < 65) {
                                $appreciation = 'Peu satisfaisant';
                                $badgeClass = 'badge-danger';
                            } elseif ($noteFinale <= 85) {
                                $appreciation = 'Satisfaisant';
                                $badgeClass = 'badge-warning';
                            } else {
                                $appreciation = 'Très satisfaisant';
                                $badgeClass = 'badge-success';
                            }

                            $noteClass = $noteFinale >= 75 ? 'moy-success' : ($noteFinale >= 50 ? 'moy-warning' : 'moy-danger');
                        @endphp
                        <div class="prof-card">
                            <div class="prof-card-header">
                                <div class="prof-info">
                                    <div class="prof-avatar">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div>
                                        <h4>{{ $prof->full_name }}</h4>
                                        <span class="appreciation-badge {{ $badgeClass }}">{{ $appreciation }}</span>
                                    </div>
                                </div>
                                <span class="moyenne-badge {{ $noteClass }}">{{ $noteFinale }}/100</span>
                            </div>
                            <div class="prof-card-footer">
                                <a href="{{ route('resultat_prof', $prof->id) }}" class="btn-card">
                                    <i class="fas fa-eye"></i> Détails
                                </a>
                                <a href="{{ route('rapport_prof', $prof->id) }}" class="btn-card btn-card-primary">
                                    <i class="fas fa-file-pdf"></i> Rapport
                                </a>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Aucun enseignant avec des cours actifs.
                </div>
            @endif
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .badge-count { background: rgba(255,255,255,0.2); color: white; padding: 0.35rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }

        .table-scroll-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .table-results { width: 100%; border-collapse: collapse; min-width: 700px; }
        .table-results th, .table-results td { padding: 0.75rem 0.5rem; text-align: left; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; }
        .table-results th { background: #f8fafc; font-weight: 600; color: #374151; }
        .table-results tbody tr:hover { background: #f8fafc; }
        .table-results .col-note { text-align: center; }
        .table-results .col-fixed { min-width: 200px; }

        .prof-info { display: flex; align-items: center; gap: 0.75rem; }
        .prof-avatar { width: 38px; height: 38px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 0.9rem; flex-shrink: 0; }

        .moyenne-badge { padding: 0.35rem 0.65rem; border-radius: 6px; font-weight: 700; color: white; display: inline-block; font-size: 0.8rem; }
        .moy-success { background: #10b981; }
        .moy-warning { background: #f59e0b; }
        .moy-danger { background: #ef4444; }

        .appreciation-badge { padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 600; display: inline-block; }
        .badge-success { background: rgba(16, 185, 129, 0.15); color: #065f46; }
        .badge-warning { background: rgba(245, 158, 11, 0.15); color: #92400e; }
        .badge-danger { background: rgba(239, 68, 68, 0.15); color: #991b1b; }

        .action-buttons { display: flex; gap: 0.5rem; justify-content: center; }
        .btn-action { width: 32px; height: 32px; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white; text-decoration: none; transition: transform 0.2s; }
        .btn-action:hover { transform: scale(1.1); color: white; }
        .btn-view { background: #3b82f6; }
        .btn-pdf { background: #667eea; }

        .mobile-cards { display: none; }
        .prof-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 1rem; overflow: hidden; border: 1px solid #e2e8f0; }
        .prof-card-header { display: flex; justify-content: space-between; align-items: flex-start; padding: 1rem; gap: 1rem; }
        .prof-card-header .prof-info { flex: 1; }
        .prof-card-header h4 { margin: 0 0 0.35rem 0; font-size: 0.95rem; color: #1e293b; }
        .prof-card-footer { display: flex; border-top: 1px solid #e2e8f0; }
        .btn-card { flex: 1; padding: 0.75rem; text-align: center; text-decoration: none; color: #64748b; font-size: 0.85rem; font-weight: 500; display: flex; align-items: center; justify-content: center; gap: 0.5rem; transition: background 0.2s; }
        .btn-card:hover { background: #f8fafc; color: #1e293b; }
        .btn-card-primary { background: #667eea; color: white; }
        .btn-card-primary:hover { background: #5a67d8; color: white; }

        @media (max-width: 992px) { .table-scroll-wrapper { display: none; } .mobile-cards { display: block; } }
        @media (max-width: 480px) {
            .prof-card-header { flex-direction: column; }
            .prof-card-header .moyenne-badge { align-self: flex-start; margin-top: 0.5rem; }
        }
    </style>
@endpush
