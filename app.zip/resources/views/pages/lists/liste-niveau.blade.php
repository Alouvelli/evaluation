@extends('layouts.admin')

@section('title', 'Liste des Niveaux')

@section('content')
    @php
        use App\Http\Controllers\EvaluationsController;
    @endphp

    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-layer-group"></i> Résultats par Niveau</h3>
        </div>
        <div class="card-body">
            @if($niveaux->count() > 0)
                <div class="niveau-grid">
                    @foreach($niveaux as $niveau)
                        @php
                            $tauxParticipation = EvaluationsController::getTauxDeParticipationNiveau($niveau->id_niveau);
                        @endphp
                        <a href="{{ route('resultat_niveau', $niveau->id_niveau) }}" class="niveau-card">
                            <div class="niveau-icon">
                                <i class="fas fa-graduation-cap"></i>
                            </div>
                            <div class="niveau-content">
                                <h4>{{ $niveau->libelle_niveau }}</h4>
                                <div class="niveau-stats">
                                    <span class="stat">
                                        <i class="fas fa-chart-pie"></i>
                                        {{ $tauxParticipation }}% participation
                                    </span>
                                </div>
                            </div>
                            <div class="niveau-arrow">
                                <i class="fas fa-chevron-right"></i>
                            </div>
                        </a>
                    @endforeach
                </div>
            @else
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Aucun niveau disponible.
                </div>
            @endif
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .niveau-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1rem;
        }

        .niveau-card {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.25rem;
            background: white;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            text-decoration: none;
            color: inherit;
            transition: all 0.3s ease;
        }

        .niveau-card:hover {
            border-color: var(--primary);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.15);
            transform: translateY(-2px);
        }

        .niveau-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.25rem;
            flex-shrink: 0;
        }

        .niveau-content {
            flex: 1;
        }

        .niveau-content h4 {
            font-size: 1.1rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0 0 0.5rem 0;
        }

        .niveau-stats {
            display: flex;
            gap: 1rem;
        }

        .niveau-stats .stat {
            font-size: 0.85rem;
            color: #64748b;
            display: flex;
            align-items: center;
            gap: 0.35rem;
        }

        .niveau-stats .stat i {
            color: var(--primary);
        }

        .niveau-arrow {
            color: #94a3b8;
            font-size: 1rem;
            transition: transform 0.3s ease;
        }

        .niveau-card:hover .niveau-arrow {
            transform: translateX(4px);
            color: var(--primary);
        }
    </style>
@endpush
