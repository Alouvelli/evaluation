@extends('layouts.admin')

@section('title', 'Import des Étudiants')

@section('content')
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 1.5rem;">
        <!-- Import Form Card -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-file-import"></i> Importer des Étudiants</h3>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('import_etudiants') }}" enctype="multipart/form-data">
                    @csrf

                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-users"></i> Classe <span style="color: var(--danger);">*</span>
                        </label>
                        <select class="form-control form-select" name="classe" required>
                            <option value="">-- Sélectionner une classe --</option>
                            @foreach($classes as $classe)
                                <option value="{{ $classe->id }}">
                                    {{ $classe->niveau->libelle_niveau ?? '' }} - {{ $classe->libelle }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">
                            <i class="fas fa-file-excel"></i> Fichier Excel <span style="color: var(--danger);">*</span>
                        </label>
                        <div class="file-upload">
                            <input type="file" name="file" id="fileInput" accept=".xlsx,.xls,.csv" required>
                            <label for="fileInput" class="file-label">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <span id="fileName">Cliquer pour choisir un fichier</span>
                            </label>
                        </div>
                        <small style="color: var(--gray);">Formats acceptés : .xlsx, .xls, .csv (max 5 Mo)</small>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-upload"></i> Importer les étudiants
                    </button>
                </form>
            </div>
        </div>

        <!-- Instructions Card -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-info-circle"></i> Instructions</h3>
            </div>
            <div class="card-body">
                <h4 style="font-size: 1rem; margin-bottom: 1rem;">Format du fichier Excel :</h4>
                <p style="color: var(--gray); margin-bottom: 1rem;">
                    Le fichier doit contenir une colonne <strong>matricule</strong> avec les matricules des étudiants.
                </p>

                <div class="example-table">
                    <table>
                        <thead>
                            <tr>
                                <th>matricule</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>L1DS& BD-25-4003</td></tr>
                            <tr><td>L3GL-25-3699</td></tr>
                            <tr><td>M1RESI-25-3678</td></tr>
                            <tr><td>...</td></tr>
                        </tbody>
                    </table>
                </div>

                <div class="alert alert-info" style="margin-top: 1rem;">
                    <i class="fas fa-lightbulb"></i>
                    <div>
                        <strong>Note :</strong> Les matricules peuvent être au format
                        <code>L1DS& BD-25-4003</code> ou <code>L1DS& BD254003</code>.
                        Les tirets seront automatiquement supprimés.
                    </div>
                </div>

                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>Attention :</strong> L'import réinitialise le statut d'évaluation
                        des étudiants existants de la classe sélectionnée.
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Students by Class -->
    <div class="card" style="margin-top: 1.5rem;">
        <div class="card-header">
            <h3><i class="fas fa-users"></i> Étudiants par classe</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table datatable">
                    <thead>
                        <tr>
                            <th>Classe</th>
                            <th>Niveau</th>
                            <th>Nb. Étudiants</th>
                            <th>Ont évalué</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($classes as $classe)
                            @php
                                $nbEtudiants = \App\Models\Etudiant::where('id_classe', $classe->id)->count();
                                $nbEvalues = \App\Models\Etudiant::where('id_classe', $classe->id)->where('statut', 1)->count();
                            @endphp
                            <tr>
                                <td><strong>{{ $classe->libelle }}</strong></td>
                                <td>
                                    <span class="badge badge-primary">{{ $classe->niveau->libelle_niveau ?? 'N/A' }}</span>
                                </td>
                                <td>
                                    <span class="badge {{ $nbEtudiants > 0 ? 'badge-success' : 'badge-warning' }}">
                                        {{ $nbEtudiants }} étudiant(s)
                                    </span>
                                </td>
                                <td>
                                    @if($nbEtudiants > 0)
                                        <div class="progress-bar-mini" style="width: 80px;">
                                            <div class="progress-fill-mini" style="width: {{ ($nbEvalues / $nbEtudiants) * 100 }}%; background: var(--success);"></div>
                                        </div>
                                        <span style="font-size: 0.85rem;">{{ $nbEvalues }}/{{ $nbEtudiants }}</span>
                                    @else
                                        <span class="badge badge-warning">--</span>
                                    @endif
                                </td>
                                <td>
                                    @if($nbEtudiants > 0)
                                        <a href="{{ route('etudiants.byClasse', $classe->id) }}" class="btn btn-sm btn-outline">
                                            <i class="fas fa-eye"></i> Voir
                                        </a>
                                    @else
                                        <span style="color: var(--gray);">Aucun étudiant</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@push('styles')
<style>
    .file-upload {
        position: relative;
    }

    .file-upload input[type="file"] {
        position: absolute;
        opacity: 0;
        width: 100%;
        height: 100%;
        cursor: pointer;
    }

    .file-label {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 2rem;
        border: 2px dashed var(--gray-light);
        border-radius: 12px;
        background: var(--light);
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .file-label:hover {
        border-color: var(--primary);
        background: rgba(102, 126, 234, 0.05);
    }

    .file-label i {
        font-size: 2rem;
        color: var(--primary);
        margin-bottom: 0.5rem;
    }

    .file-label span {
        color: var(--gray);
        font-size: 0.9rem;
    }

    .example-table {
        background: var(--light);
        border-radius: 8px;
        overflow: hidden;
    }

    .example-table table {
        width: 100%;
        border-collapse: collapse;
    }

    .example-table th {
        background: var(--primary);
        color: white;
        padding: 0.75rem;
        font-weight: 600;
    }

    .example-table td {
        padding: 0.5rem 0.75rem;
        border-bottom: 1px solid var(--gray-light);
        font-family: monospace;
    }

    .progress-bar-mini {
        height: 6px;
        background: var(--gray-light);
        border-radius: 3px;
        overflow: hidden;
        margin-bottom: 0.25rem;
    }

    .progress-fill-mini {
        height: 100%;
        border-radius: 3px;
    }

    code {
        background: var(--light);
        padding: 0.2rem 0.5rem;
        border-radius: 4px;
        font-family: monospace;
        color: var(--primary);
    }
</style>
@endpush

@push('scripts')
<script>
    document.getElementById('fileInput').addEventListener('change', function(e) {
        const fileName = e.target.files[0]?.name || 'Cliquer pour choisir un fichier';
        document.getElementById('fileName').textContent = fileName;
    });
</script>
@endpush
