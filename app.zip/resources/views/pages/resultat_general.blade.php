@extends('layouts.admin')

@section('title', 'Résultat Général')

@section('content')
    <!-- Stats globales -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon primary">
                <i class="fas fa-chalkboard-teacher"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $profs }}</h3>
                <p>Professeurs</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon success">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $classes->count() }}</h3>
                <p>Classes</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon info">
                <i class="fas fa-question-circle"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $questions->count() }}</h3>
                <p>Questions</p>
            </div>
        </div>
    </div>

    <!-- Sélecteur de classe -->
    <div class="card mb-4">
        <div class="card-header">
            <h3><i class="fas fa-filter"></i> Sélectionner une classe</h3>
        </div>
        <div class="card-body">
            <select id="classeSelect" class="classe-select">
                <option value="">-- Choisir une classe --</option>
                @foreach($classes as $classe)
                    <option value="{{ $classe->id }}">
                        {{ $classe->niveau->libelle_niveau ?? '' }} {{ $classe->libelle }}
                    </option>
                @endforeach
            </select>
        </div>
    </div>

    <!-- Loading -->
    <div id="loadingZone" style="display: none;">
        <div class="loading-box">
            <div class="spinner"></div>
            <p>Chargement des résultats...</p>
        </div>
    </div>

    <!-- Message si pas de données -->
    <div id="emptyZone" style="display: none;">
        <div class="alert alert-info">
            <i class="fas fa-info-circle"></i>
            <strong>Aucun cours actif</strong> - Cette classe n'a pas de cours actif ou pas encore d'évaluations.
        </div>
    </div>

    <!-- Zone de résultats -->
    <div id="resultatsZone" style="display: none;">
        <!-- Stats classe -->
        <div class="stats-row stats-mini" id="classeStats">
            <div class="stat-card mini">
                <div class="stat-icon info">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-content">
                    <h3 id="nbCours">0</h3>
                    <p>Cours</p>
                </div>
            </div>
            <div class="stat-card mini">
                <div class="stat-icon success">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="stat-content">
                    <h3 id="nbEtudiants">0</h3>
                    <p>Étudiants</p>
                </div>
            </div>
            <div class="stat-card mini">
                <div class="stat-icon warning">
                    <i class="fas fa-chart-pie"></i>
                </div>
                <div class="stat-content">
                    <h3 id="tauxParticipation">0%</h3>
                    <p>Participation</p>
                </div>
            </div>
            <div class="stat-card mini">
                <div class="stat-icon primary">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-content">
                    <h3 id="moyenneClasse">0%</h3>
                    <p>Moyenne</p>
                </div>
            </div>
        </div>

        <!-- Tableau des résultats -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-table"></i> Résultats - <span id="classeNom"></span></h3>
            </div>
            <div class="card-body">
                <!-- Vue Desktop -->
                <div class="table-scroll-wrapper" id="desktopTable">
                    <table class="table-results">
                        <thead>
                        <tr>
                            <th class="col-fixed">Professeur</th>
                            <th>Cours</th>
                            @foreach($questions as $q)
                                <th class="col-note" title="{{ $q->libelle }}">Q{{ $q->idQ }}</th>
                            @endforeach
                            <th class="col-note">Moy.</th>
                        </tr>
                        </thead>
                        <tbody id="resultatsBody"></tbody>
                    </table>
                </div>

                <!-- Vue Mobile -->
                <div class="mobile-cards" id="mobileCards"></div>
            </div>
        </div>

        <!-- Graphique -->
        <div class="card mt-4">
            <div class="card-header">
                <h3><i class="fas fa-chart-bar"></i> Graphique des moyennes</h3>
            </div>
            <div class="card-body">
                <canvas id="chartMoyennes" height="100"></canvas>
            </div>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .stats-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 1.5rem; }
        .stats-row.stats-mini { grid-template-columns: repeat(4, 1fr); }
        .stat-card { background: white; border-radius: 12px; padding: 1.25rem; display: flex; align-items: center; gap: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .stat-card.mini { padding: 1rem; }
        .stat-icon { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; color: white; flex-shrink: 0; }
        .stat-card.mini .stat-icon { width: 42px; height: 42px; font-size: 1rem; }
        .stat-icon.primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.success { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .stat-icon.info { background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); }
        .stat-icon.warning { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
        .stat-content h3 { font-size: 1.1rem; font-weight: 700; color: #1e293b; margin: 0; }
        .stat-card.mini .stat-content h3 { font-size: 1rem; }
        .stat-content p { font-size: 0.8rem; color: #64748b; margin: 0; }

        .classe-select { width: 100%; max-width: 400px; padding: 0.75rem 1rem; font-size: 1rem; border: 2px solid #e2e8f0; border-radius: 10px; background: white; }
        .classe-select:focus { border-color: #667eea; outline: none; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.15); }

        .loading-box { text-align: center; padding: 3rem; }
        .spinner { width: 40px; height: 40px; border: 3px solid #e2e8f0; border-top-color: #667eea; border-radius: 50%; animation: spin 0.8s linear infinite; margin: 0 auto 1rem; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .loading-box p { color: #64748b; }

        .table-scroll-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .table-results { width: 100%; border-collapse: collapse; min-width: 800px; }
        .table-results th, .table-results td { padding: 0.75rem 0.5rem; text-align: left; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; white-space: nowrap; }
        .table-results th { background: #f8fafc; font-weight: 600; color: #374151; }
        .table-results tbody tr:hover { background: #f8fafc; }
        .table-results .col-note { text-align: center; min-width: 55px; }
        .table-results .col-fixed { min-width: 150px; }

        .cell-good { background: rgba(16, 185, 129, 0.15) !important; color: #065f46 !important; font-weight: 600; }
        .cell-warning { background: rgba(245, 158, 11, 0.15) !important; color: #92400e !important; font-weight: 600; }
        .cell-danger { background: rgba(239, 68, 68, 0.15) !important; color: #991b1b !important; font-weight: 600; }

        .moyenne-badge { padding: 0.35rem 0.65rem; border-radius: 6px; font-weight: 700; color: white; display: inline-block; font-size: 0.8rem; }
        .moy-success { background: #10b981; }
        .moy-warning { background: #f59e0b; }
        .moy-danger { background: #ef4444; }

        .mobile-cards { display: none; }
        .result-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 1rem; overflow: hidden; border: 1px solid #e2e8f0; }
        .result-card-header { display: flex; justify-content: space-between; align-items: flex-start; padding: 1rem; background: #f8fafc; border-bottom: 1px solid #e2e8f0; gap: 1rem; }
        .result-info h4 { margin: 0 0 0.25rem 0; font-size: 0.95rem; color: #1e293b; font-weight: 600; }
        .result-info p { margin: 0; font-size: 0.8rem; color: #64748b; }
        .result-card-body { padding: 1rem; }
        .notes-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.5rem; }
        .note-item { display: flex; flex-direction: column; align-items: center; padding: 0.5rem 0.25rem; border-radius: 8px; background: #f8fafc; border: 1px solid #e2e8f0; }
        .note-label { font-size: 0.65rem; color: #64748b; font-weight: 600; }
        .note-value { font-size: 0.85rem; font-weight: 700; color: #1e293b; }

        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } .stats-row.stats-mini { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 992px) { #desktopTable { display: none; } .mobile-cards { display: block !important; } }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: 1fr 1fr; gap: 0.75rem; }
            .stat-card { padding: 1rem; }
            .stat-icon { width: 42px; height: 42px; font-size: 1rem; }
            .stat-content h3 { font-size: 0.95rem; }
            .notes-grid { gap: 0.35rem; }
            .note-item { padding: 0.4rem 0.2rem; }
            .note-label { font-size: 0.6rem; }
            .note-value { font-size: 0.75rem; }
        }
        @media (max-width: 480px) { .result-card-header { flex-direction: column; } }
    </style>
@endpush

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const classeSelect = document.getElementById('classeSelect');
            const resultatsZone = document.getElementById('resultatsZone');
            const loadingZone = document.getElementById('loadingZone');
            const emptyZone = document.getElementById('emptyZone');
            const resultatsBody = document.getElementById('resultatsBody');
            const mobileCards = document.getElementById('mobileCards');
            const nbQuestions = {{ $questions->count() }};

            let chart = null;

            classeSelect.addEventListener('change', function() {
                const classeId = this.value;

                if (!classeId) {
                    resultatsZone.style.display = 'none';
                    emptyZone.style.display = 'none';
                    return;
                }

                loadingZone.style.display = 'block';
                resultatsZone.style.display = 'none';
                emptyZone.style.display = 'none';

                fetch(`/api/resultat-classe/${classeId}`)
                    .then(response => response.json())
                    .then(data => {
                        loadingZone.style.display = 'none';

                        if (data.cours.length === 0) {
                            emptyZone.style.display = 'block';
                            return;
                        }

                        resultatsZone.style.display = 'block';

                        // Stats
                        document.getElementById('classeNom').textContent = data.classe.niveau + ' ' + data.classe.libelle;
                        document.getElementById('nbCours').textContent = data.cours.length;
                        document.getElementById('nbEtudiants').textContent = data.classe.nbEtudiants;
                        document.getElementById('tauxParticipation').textContent = data.classe.tauxParticipation + '%';

                        // Moyenne classe
                        let totalMoyenne = 0;
                        data.cours.forEach(c => {
                            const moy = c.notes.reduce((a, b) => a + b, 0) / c.notes.length;
                            totalMoyenne += moy;
                        });
                        const moyenneClasse = Math.round(totalMoyenne / data.cours.length);
                        document.getElementById('moyenneClasse').textContent = moyenneClasse + '%';

                        // Tableau desktop
                        resultatsBody.innerHTML = '';
                        data.cours.forEach(c => {
                            const moy = Math.round(c.notes.reduce((a, b) => a + b, 0) / c.notes.length);
                            let moyClass = moy >= 75 ? 'moy-success' : (moy >= 50 ? 'moy-warning' : 'moy-danger');

                            let row = `<tr><td class="col-fixed"><strong>${c.professeur}</strong></td><td>${c.libelle}</td>`;
                            c.notes.forEach(note => {
                                let cellClass = note >= 75 ? 'cell-good' : (note >= 50 ? 'cell-warning' : 'cell-danger');
                                row += `<td class="col-note ${note > 0 ? cellClass : ''}">${note > 0 ? note + '%' : '-'}</td>`;
                            });
                            row += `<td class="col-note"><span class="moyenne-badge ${moyClass}">${moy}%</span></td></tr>`;
                            resultatsBody.innerHTML += row;
                        });

                        // Cards mobile
                        mobileCards.innerHTML = '';
                        data.cours.forEach(c => {
                            const moy = Math.round(c.notes.reduce((a, b) => a + b, 0) / c.notes.length);
                            let moyClass = moy >= 75 ? 'moy-success' : (moy >= 50 ? 'moy-warning' : 'moy-danger');

                            let notesHtml = '';
                            c.notes.forEach((note, i) => {
                                let cellClass = note >= 75 ? 'cell-good' : (note >= 50 ? 'cell-warning' : 'cell-danger');
                                notesHtml += `<div class="note-item ${note > 0 ? cellClass : ''}"><span class="note-label">Q${i+1}</span><span class="note-value">${note > 0 ? note + '%' : '-'}</span></div>`;
                            });

                            mobileCards.innerHTML += `
                        <div class="result-card">
                            <div class="result-card-header">
                                <div class="result-info">
                                    <h4>${c.professeur}</h4>
                                    <p>${c.libelle}</p>
                                </div>
                                <span class="moyenne-badge ${moyClass}">${moy}%</span>
                            </div>
                            <div class="result-card-body">
                                <div class="notes-grid">${notesHtml}</div>
                            </div>
                        </div>`;
                        });

                        updateChart(data.cours);
                    })
                    .catch(error => {
                        console.error('Erreur:', error);
                        loadingZone.style.display = 'none';
                        emptyZone.style.display = 'block';
                    });
            });

            function updateChart(coursData) {
                const ctx = document.getElementById('chartMoyennes').getContext('2d');

                if (chart) chart.destroy();

                const labels = coursData.map(c => c.professeur.split(' ').slice(0, 2).join(' '));
                const moyennes = coursData.map(c => Math.round(c.notes.reduce((a, b) => a + b, 0) / c.notes.length));

                const colors = moyennes.map(m => m >= 75 ? 'rgba(16, 185, 129, 0.8)' : (m >= 50 ? 'rgba(245, 158, 11, 0.8)' : 'rgba(239, 68, 68, 0.8)'));

                chart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{ label: 'Moyenne (%)', data: moyennes, backgroundColor: colors, borderRadius: 6 }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, max: 100, ticks: { callback: v => v + '%' } },
                            x: { ticks: { maxRotation: 45, minRotation: 45 } }
                        }
                    }
                });
            }
        });
    </script>
@endpush
