@extends('layouts.admin')

@section('title', 'Résultat - ' . $prof->full_name)

@section('content')
    @php
        use App\Http\Controllers\EvaluationsController;

        if ($noteFinale < 65) {
            $appreciation = 'Peu satisfaisant';
            $appreciationClass = 'danger';
        } elseif ($noteFinale <= 85) {
            $appreciation = 'Satisfaisant';
            $appreciationClass = 'warning';
        } else {
            $appreciation = 'Très satisfaisant';
            $appreciationClass = 'success';
        }
    @endphp

        <!-- Stats -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon primary">
                <i class="fas fa-user"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $prof->full_name }}</h3>
                <p>Enseignant</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon info">
                <i class="fas fa-book"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $cours->count() }}</h3>
                <p>Cours</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon {{ $noteFinale >= 75 ? 'success' : ($noteFinale >= 50 ? 'warning' : 'danger') }}">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $noteFinale }}/100</h3>
                <p>Note Finale</p>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-icon {{ $appreciationClass }}">
                <i class="fas fa-award"></i>
            </div>
            <div class="stat-content">
                <h3>{{ $appreciation }}</h3>
                <p>Appréciation</p>
            </div>
        </div>
    </div>

    <!-- Tableau des résultats -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-table"></i> Résultats par Cours</h3>
            <div class="header-actions">
                <a href="{{ route('rapport_prof', $prof->id) }}" class="btn btn-sm btn-primary">
                    <i class="fas fa-file-pdf"></i> <span class="btn-text">Rapport PDF</span>
                </a>
                <a href="{{ route('liste_prof') }}" class="btn btn-sm btn-back">
                    <i class="fas fa-arrow-left"></i> <span class="btn-text">Retour</span>
                </a>
            </div>
        </div>
        <div class="card-body">
            @if($cours->count() > 0)
                <!-- Vue Desktop avec scroll -->
                <div class="table-scroll-wrapper">
                    <table class="table-results">
                        <thead>
                        <tr>
                            <th class="col-fixed">Cours</th>
                            <th>Classe</th>
                            @foreach($questions as $q)
                                <th class="col-note" title="{{ $q->libelle }}">Q{{ $q->idQ }}</th>
                            @endforeach
                            <th class="col-note">Moy.</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($cours as $c)
                            @php
                                $totalNotes = 0;
                                $countNotes = 0;
                            @endphp
                            <tr>
                                <td class="col-fixed"><strong>{{ $c->libelle_cours }}</strong></td>
                                <td>
                                        <span class="badge badge-primary">
                                            {{ $c->classe->niveau->libelle_niveau ?? '' }} {{ $c->classe->libelle ?? '' }}
                                        </span>
                                </td>
                                @foreach($questions as $q)
                                    @php
                                        $note = EvaluationsController::getPourcentByCours($c->id_cours, $q->idQ, $prof->id);
                                        $totalNotes += $note;
                                        $countNotes++;

                                        $cellClass = '';
                                        if($note > 0) {
                                            if($note >= 75) $cellClass = 'cell-good';
                                            elseif($note >= 50) $cellClass = 'cell-warning';
                                            else $cellClass = 'cell-danger';
                                        }
                                    @endphp
                                    <td class="col-note {{ $cellClass }}">{{ $note > 0 ? $note . '%' : '-' }}</td>
                                @endforeach
                                @php
                                    $moyenne = $countNotes > 0 ? round($totalNotes / $countNotes) : 0;
                                    $moyClass = $moyenne >= 75 ? 'moy-success' : ($moyenne >= 50 ? 'moy-warning' : 'moy-danger');
                                @endphp
                                <td class="col-note"><span class="moyenne-badge {{ $moyClass }}">{{ $moyenne }}%</span></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Vue Mobile Cards -->
                <div class="mobile-cards">
                    @foreach($cours as $c)
                        @php
                            $totalNotes = 0;
                            $countNotes = 0;
                            $notesArray = [];
                            foreach($questions as $q) {
                                $note = EvaluationsController::getPourcentByCours($c->id_cours, $q->idQ, $prof->id);
                                $totalNotes += $note;
                                $countNotes++;
                                $notesArray[] = ['q' => $q->idQ, 'note' => $note];
                            }
                            $moyenne = $countNotes > 0 ? round($totalNotes / $countNotes) : 0;
                            $moyClass = $moyenne >= 75 ? 'moy-success' : ($moyenne >= 50 ? 'moy-warning' : 'moy-danger');
                        @endphp
                        <div class="result-card">
                            <div class="result-card-header">
                                <div class="result-info">
                                    <h4>{{ $c->libelle_cours }}</h4>
                                    <span class="badge badge-primary">{{ $c->classe->niveau->libelle_niveau ?? '' }} {{ $c->classe->libelle ?? '' }}</span>
                                </div>
                                <span class="moyenne-badge {{ $moyClass }}">{{ $moyenne }}%</span>
                            </div>
                            <div class="result-card-body">
                                <div class="notes-grid">
                                    @foreach($notesArray as $n)
                                        @php
                                            $cellClass = '';
                                            if($n['note'] > 0) {
                                                if($n['note'] >= 75) $cellClass = 'cell-good';
                                                elseif($n['note'] >= 50) $cellClass = 'cell-warning';
                                                else $cellClass = 'cell-danger';
                                            }
                                        @endphp
                                        <div class="note-item {{ $cellClass }}">
                                            <span class="note-label">Q{{ $n['q'] }}</span>
                                            <span class="note-value">{{ $n['note'] > 0 ? $n['note'] . '%' : '-' }}</span>
                                        </div>
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Aucun cours actif pour cet enseignant.
                </div>
            @endif
        </div>
    </div>

    <!-- Graphique -->
    <div class="card mt-4">
        <div class="card-header">
            <h3><i class="fas fa-chart-bar"></i> Performance par Question</h3>
        </div>
        <div class="card-body">
            <canvas id="chartQuestions" height="100"></canvas>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .stats-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.5rem; }
        .stat-card { background: white; border-radius: 12px; padding: 1.25rem; display: flex; align-items: center; gap: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .stat-icon { width: 50px; height: 50px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; color: white; flex-shrink: 0; }
        .stat-icon.primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.success { background: linear-gradient(135deg, #10b981 0%, #059669 100%); }
        .stat-icon.info { background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); }
        .stat-icon.warning { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); }
        .stat-icon.danger { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); }
        .stat-content h3 { font-size: 1.1rem; font-weight: 700; color: #1e293b; margin: 0; }
        .stat-content p { font-size: 0.8rem; color: #64748b; margin: 0; }

        .header-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        .btn-back { background: rgba(255,255,255,0.2); color: white; border: none; padding: 0.5rem 1rem; border-radius: 6px; display: inline-flex; align-items: center; gap: 0.5rem; text-decoration: none; }
        .btn-back:hover { background: rgba(255,255,255,0.3); color: white; }

        .table-scroll-wrapper { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        .table-results { width: 100%; border-collapse: collapse; min-width: 800px; }
        .table-results th, .table-results td { padding: 0.75rem 0.5rem; text-align: left; border-bottom: 1px solid #e2e8f0; font-size: 0.85rem; white-space: nowrap; }
        .table-results th { background: #f8fafc; font-weight: 600; color: #374151; }
        .table-results tbody tr:hover { background: #f8fafc; }
        .table-results .col-note { text-align: center; min-width: 55px; }
        .table-results .col-fixed { min-width: 150px; }

        .cell-good { background: rgba(16, 185, 129, 0.15) !important; color: #065f46 !important; font-weight: 600; }
        .cell-warning { background: rgba(245, 158, 11, 0.15) !important; color: #92400e !important; font-weight: 600; }
        .cell-danger { background: rgba(239, 68, 68, 0.15) !important; color: #991b1b !important; font-weight: 600; }

        .moyenne-badge { padding: 0.35rem 0.65rem; border-radius: 6px; font-weight: 700; color: white; display: inline-block; font-size: 0.8rem; }
        .moy-success { background: #10b981; }
        .moy-warning { background: #f59e0b; }
        .moy-danger { background: #ef4444; }

        .badge-primary { background: rgba(102, 126, 234, 0.15); color: #667eea; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; font-weight: 600; }

        .mobile-cards { display: none; }
        .result-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 1rem; overflow: hidden; border: 1px solid #e2e8f0; }
        .result-card-header { display: flex; justify-content: space-between; align-items: flex-start; padding: 1rem; background: #f8fafc; border-bottom: 1px solid #e2e8f0; gap: 1rem; }
        .result-info h4 { margin: 0 0 0.5rem 0; font-size: 0.95rem; color: #1e293b; font-weight: 600; }
        .result-card-body { padding: 1rem; }
        .notes-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 0.5rem; }
        .note-item { display: flex; flex-direction: column; align-items: center; padding: 0.5rem 0.25rem; border-radius: 8px; background: #f8fafc; border: 1px solid #e2e8f0; }
        .note-label { font-size: 0.65rem; color: #64748b; font-weight: 600; }
        .note-value { font-size: 0.85rem; font-weight: 700; color: #1e293b; }
        .note-item.cell-good .note-value { color: #065f46; }
        .note-item.cell-warning .note-value { color: #92400e; }
        .note-item.cell-danger .note-value { color: #991b1b; }

        @media (max-width: 1200px) { .stats-row { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 992px) { .table-scroll-wrapper { display: none; } .mobile-cards { display: block; } }
        @media (max-width: 768px) {
            .stats-row { grid-template-columns: repeat(2, 1fr); gap: 0.75rem; }
            .stat-card { padding: 1rem; }
            .stat-icon { width: 42px; height: 42px; font-size: 1rem; }
            .stat-content h3 { font-size: 0.95rem; }
            .btn-text { display: none; }
            .header-actions { width: 100%; }
            .notes-grid { gap: 0.35rem; }
            .note-item { padding: 0.4rem 0.2rem; }
            .note-label { font-size: 0.6rem; }
            .note-value { font-size: 0.75rem; }
        }
        @media (max-width: 480px) { .result-card-header { flex-direction: column; } .moyenne-badge { align-self: flex-start; } }
    </style>
@endpush

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('chartQuestions').getContext('2d');

            const questionLabels = [@foreach($questions as $q)'Q{{ $q->idQ }}',@endforeach];

            const moyennesParQuestion = [
                @foreach($questions as $q)
                    @php
                        $total = 0;
                        $count = 0;
                        foreach($cours as $c) {
                            $note = EvaluationsController::getPourcentByCours($c->id_cours, $q->idQ, $prof->id);
                            if ($note > 0) {
                                $total += $note;
                                $count++;
                            }
                        }
                        $moyQ = $count > 0 ? round($total / $count) : 0;
                    @endphp
                    {{ $moyQ }},
                @endforeach
            ];

            const colors = moyennesParQuestion.map(m => {
                if (m >= 75) return 'rgba(16, 185, 129, 0.8)';
                if (m >= 50) return 'rgba(245, 158, 11, 0.8)';
                return 'rgba(239, 68, 68, 0.8)';
            });

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: questionLabels,
                    datasets: [{
                        label: 'Moyenne (%)',
                        data: moyennesParQuestion,
                        backgroundColor: colors,
                        borderRadius: 6,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { beginAtZero: true, max: 100, ticks: { callback: function(value) { return value + '%'; } } }
                    }
                }
            });
        });
    </script>
@endpush
